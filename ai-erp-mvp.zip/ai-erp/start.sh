#!/bin/bash
echo "========================================"
echo "  AI-ERP - Запуск системы"
echo "========================================"
echo ""
echo "Проверка Node.js..."
if ! command -v node &> /dev/null; then
  echo "ОШИБКА: Node.js не установлен!"
  echo "Скачайте с https://nodejs.org"
  exit 1
fi
echo "Node.js: $(node --version)"
echo ""
echo "Установка зависимостей..."
npm install
echo ""
echo "Запуск сервера..."
echo "Сайт откроется на http://localhost:3000"
npm start
