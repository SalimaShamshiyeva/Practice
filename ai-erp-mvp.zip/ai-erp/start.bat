@echo off
echo ========================================
echo   AI-ERP - Запуск системы
echo ========================================
echo.
echo Проверка Node.js...
node --version >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
  echo ОШИБКА: Node.js не установлен!
  echo Скачайте с https://nodejs.org
  pause
  exit
)
echo Node.js найден!
echo.
echo Установка зависимостей...
call npm install
echo.
echo Запуск сервера...
echo Сайт откроется на http://localhost:3000
echo.
call npm start
